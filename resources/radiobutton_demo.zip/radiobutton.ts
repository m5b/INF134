// importing local code, code we have written
import {IdleUpWidgetState, PressedWidgetState } from "../core/ui";
import {Window, Widget, RoleType, EventArgs} from "../core/ui";
// importing code from SVG.js library
import {Rect, Text, Box} from "../core/ui";

class RadioItem extends Widget{
    private _rect: Rect;
    private _innerrect: Rect;
    private _text: Text;
    private _input: string;
    private _fontSize: number;
    private _text_y: number;
    private _text_x: number;
    private defaultText: string= "Button";
    private defaultFontSize: number = 18;
    private defaultWidth: number = 25;
    private defaultHeight: number = 25;
    private id: number = -1;

    constructor(parent:Window){
        super(parent);
        // set defaults
        this.height = this.defaultHeight;
        this.width = this.defaultWidth;
        this._input = this.defaultText;
        this._fontSize = this.defaultFontSize;
        // set Aria role
        this.role = RoleType.button;
        // render widget
        this.render();
        // set default or starting state
        this.setState(new IdleUpWidgetState());
        // prevent text selection
        this.selectable = false;
    }

    set label(label:string){
        this._input = label;
        this.update();
    }

    get label(){
        return this._input;
    }

    set fontSize(size:number){
        this._fontSize= size;
        this.update();
    }

    public deselect(){
        this._innerrect.fill("white");
    }

    private positionText(){
        let box:Box = this._text.bbox();
        // in TS, the prepending with + performs a type conversion from string to number
        this._text_y = (+this._rect.y() + ((+this._rect.height()/2)) - (box.height/2));
        this._text.x(+this._rect.x() + +this._rect.width() + 4);
        if (this._text_y > 0){
            this._text.y(this._text_y);
        }
    }
    
    render(): void {
        this._group = (this.parent as Window).window.group();
        this._rect = this._group.rect(this.width, this.height);
        this._rect.stroke("black");
        this._innerrect = this._group.rect(this.width-6, this.height-6);
        this._innerrect.move(3,3);
        this._innerrect.fill("white");
        this._text = this._group.text(this._input);
        this._backcolor = "white";
        // Set the outer svg element 
        this.outerSvg = this._group;
        // Add a transparent rect on top of text to 
        // prevent selection cursor and to handle mouse events
        let eventrect = this._group.rect(this.width, this.height).opacity(0).attr('id', 0);

        // register objects that should receive event notifications.
        // for this widget, we want to know when the group or rect objects
        // receive events
        this.registerEvent(eventrect);
    }

    override update(): void {
        if(this._text != null)
            this._text.font('size', this._fontSize);
            this._text.text(this._input);
            this.positionText();

        if(this._rect != null)
            this._rect.fill(this.backcolor);
        
        super.update();
    }
    
    pressReleaseState(): void{
        if (this.previousState instanceof PressedWidgetState){
            this._innerrect.fill("silver");
            this.raise(new EventArgs(this, undefined, this.id), new PressedWidgetState());
        }
    }

    onChange(callback: { (event?:any): void }):void{
        this.attach(callback, new PressedWidgetState());
    }
    
    //TODO: give the states something to do! Use these methods to control the visual appearance of your
    //widget
    idleupState(): void {
    }
    idledownState(): void {
    }
    pressedState(): void {
    }
    hoverState(): void {
    }
    hoverPressedState(): void {
    }
    pressedoutState(): void {
    }
    moveState(): void {
    }
    keyupState(keyEvent?: KeyboardEvent): void {
    }
}

class RadioButton extends Widget{
    private _fontSize: number;
    private _x: number;
    private _y: number;
    private defaultFontSize: number = 18;
    private defaultWidth: number = 80;
    private defaultHeight: number = 30;

    private _items:RadioItem[]=[];

    constructor(parent:Window){
        super(parent);
        // set defaults
        this.height = this.defaultHeight;
        this.width = this.defaultWidth;
        this._fontSize = this.defaultFontSize;
        // set Aria role
        this.role = RoleType.button;
        // render widget
        this.render();
        // set default or starting state
        this.setState(new IdleUpWidgetState());
        // prevent text selection
        this.selectable = false;
    }

    set fontSize(size:number){
        this._fontSize= size;
        this.update();
    }

    public addItem(label:string): void{
        const item = new RadioItem(this.parent as Window)
        item.fontSize = this._fontSize;
        item.label = label;
        item.onChange((e:EventArgs)=>{
            this._items.forEach(item=>{
                if(item != e.obj)
                    item.deselect();
            })

            this.raise(new EventArgs(e.obj, undefined, (e.obj as RadioItem).label), new PressedWidgetState())
        })
        item.move(this._x, this._y + (this._items.length * 30))
        this._items.push(item);
    }
    
    render(): void {
    }

    override update(): void {
        super.update();
    }

    override move(x:number, y:number){
        this._x = x;
        this._y = y;
        //todo move each item
        for (let i=0; i<this._items.length; i++){
            this._items[i].move(this._x, this._y + (i * 30))
        }
    }
    

    onChange(callback: { (event?:any): void }):void{
        this.attach(callback, new PressedWidgetState());
    }
    
    pressReleaseState(): void{
    }
    idleupState(): void {
    }
    idledownState(): void {
    }
    pressedState(): void {
    }
    hoverState(): void {
    }
    hoverPressedState(): void {
    }
    pressedoutState(): void {
    }
    moveState(): void {
    }
    keyupState(keyEvent?: KeyboardEvent): void {
    }
}

export {RadioButton}